<?php
$con = mysqli_connect("localhost", "root", "1234") or die("Unable to connect");
mysqli_select_db($con, 'project');

?>
